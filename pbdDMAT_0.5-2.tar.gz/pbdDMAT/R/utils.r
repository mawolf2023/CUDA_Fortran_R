get_machine_eps <- function()
{
  .Machine$double.eps
}
